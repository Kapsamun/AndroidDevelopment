package com.mirea.kapsamunelenanikolaevna.movieproject.domain.repo;


import com.mirea.kapsamunelenanikolaevna.movieproject.data.storage.models.Movie;

public interface MovieRepository {
    boolean saveMovie(Movie movie);
    Movie getMovie();
}