package com.mirea.kapsamunelenanikolaevna.celebritybase.presantation;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.mirea.kapsamunelenanikolaevna.celebritybase.data.repository.network.NetworkApi;
import com.mirea.kapsamunelenanikolaevna.celebritybase.data.repository.network.models.CelebrityDto;
import com.mirea.kapsamunelenanikolaevna.celebritybase.data.repository.storage.room.CelebrityDao;
import com.mirea.kapsamunelenanikolaevna.celebritybase.data.repository.storage.room.CelebrityEntity;
import com.mirea.kapsamunelenanikolaevna.celebritybase.domain.models.Celebrity;
import com.mirea.kapsamunelenanikolaevna.celebritybase.domain.repo.CelebrityRepository;
import com.mirea.kapsamunelenanikolaevna.celebritybase.domain.usecase.AddCelebrityToFavoriteUseCase;
import com.mirea.kapsamunelenanikolaevna.celebritybase.domain.usecase.GetFavoriteCelebritiesUseCase;

import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {

    private final CelebrityRepository celebrityRepository;
    private final CelebrityDao celebrityDao;
    private final NetworkApi networkApi;

    private final MutableLiveData<String> celebrityResultLiveData = new MutableLiveData<>();
    private final MutableLiveData<List<Celebrity>> celebritiesLiveData = new MutableLiveData<>();

    // Тип данных — List<Celebrity>, подходящий для адаптера
    public MediatorLiveData<List<Celebrity>> mediatorCelebrityData = new MediatorLiveData<>();

    public MainViewModel(CelebrityRepository celebrityRepository, CelebrityDao celebrityDao, NetworkApi networkApi) {
        this.celebrityRepository = celebrityRepository;
        this.celebrityDao = celebrityDao;
        this.networkApi = networkApi;
        Log.d(MainViewModel.class.getSimpleName(), "MainViewModel created");

        loadCombinedData();
    }

    public LiveData<String> getCelebrityResult() {
        return celebrityResultLiveData;
    }

    // Исправлен возвращаемый тип на List<Celebrity>
    public LiveData<List<Celebrity>> getMediatorCelebrityData() {
        return mediatorCelebrityData;
    }

    public LiveData<List<Celebrity>> getCelebritiesLiveData() {
        return celebritiesLiveData;
    }

    public void saveCelebrity(String name) {
        if (name == null || name.trim().isEmpty()) {
            celebrityResultLiveData.setValue("Имя не может быть пустым!");
            return;
        }

        Celebrity celebrity = new Celebrity(
                (int) (System.currentTimeMillis() % 100000),
                name,
                "https://example.com/photo.png",
                "Известная личность"
        );

        new Thread(() -> {
            boolean result = new AddCelebrityToFavoriteUseCase(celebrityRepository).execute(celebrity);
            celebrityResultLiveData.postValue(result ? "Успешно сохранено: " + name : "Ошибка сохранения");
        }).start();
    }

    public void loadCelebrity() {
        new Thread(() -> {
            List<Celebrity> list = new GetFavoriteCelebritiesUseCase(celebrityRepository).execute();
            if (list != null && !list.isEmpty()) {
                StringBuilder builder = new StringBuilder("Сохраненные знаменитости:\n");
                for (Celebrity c : list) {
                    builder.append("• ").append(c.getName()).append("\n");
                }
                celebrityResultLiveData.postValue(builder.toString().trim());
                celebritiesLiveData.postValue(list);
            } else {
                celebrityResultLiveData.postValue("Список сохраненных пуст!");
                celebritiesLiveData.postValue(new ArrayList<>());
            }
        }).start();
    }

    // MediatorLiveData объединяет Room (БД) и MockNetworkApi (Сеть)
    public void loadCombinedData() {
        final List<Celebrity> dbResults = new ArrayList<>();
        final List<Celebrity> netResults = new ArrayList<>();

        // Источник 1: БД Room конвертируется в List<Celebrity>
        MutableLiveData<List<Celebrity>> dbSource = new MutableLiveData<>();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            new Thread(() -> {
                List<CelebrityEntity> localList = celebrityDao.getAll();
                List<Celebrity> convertedList = new ArrayList<>();
                if (localList != null) {
                    for (CelebrityEntity entity : localList) {
                        convertedList.add(new Celebrity(
                                entity.id,
                                entity.name,
                                entity.photoUrl,
                                entity.biography
                        ));
                    }
                }
                dbSource.postValue(convertedList);
            }).start();
        }, 300);

        // Источник 2: Сеть (NetworkApi) конвертируется в List<Celebrity>
        MutableLiveData<List<Celebrity>> netSource = new MutableLiveData<>();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            new Thread(() -> {
                List<CelebrityDto> remoteList = networkApi.getCelebrities();
                List<Celebrity> convertedList = new ArrayList<>();
                if (remoteList != null) {
                    for (CelebrityDto dto : remoteList) {
                        convertedList.add(new Celebrity(
                                dto.id,
                                dto.name,
                                dto.photoUrl,
                                dto.biography
                        ));
                    }
                }
                netSource.postValue(convertedList);
            }).start();
        }, 1200);

        // Подключаем источник БД к MediatorLiveData
        mediatorCelebrityData.addSource(dbSource, data -> {
            dbResults.clear();
            if (data != null) {
                dbResults.addAll(data);
            }
            updateCombinedList(dbResults, netResults);
        });

        // Подключаем источник Сети к MediatorLiveData
        mediatorCelebrityData.addSource(netSource, data -> {
            netResults.clear();
            if (data != null) {
                netResults.addAll(data);
            }
            updateCombinedList(dbResults, netResults);
        });
    }

    // Вспомогательный метод слияния списков
    private void updateCombinedList(List<Celebrity> dbList, List<Celebrity> netList) {
        List<Celebrity> combined = new ArrayList<>();

        // 1. Добавляем данные из локальной БД
        combined.addAll(dbList);

        // 2. Добавляем данные из сети (проверяя на дубликаты по имени)
        for (Celebrity remoteItem : netList) {
            boolean exists = false;
            for (Celebrity localItem : dbList) {
                if (localItem.getName().equalsIgnoreCase(remoteItem.getName())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                combined.add(remoteItem);
            }
        }

        // 3. Отправляем в MediatorLiveData
        mediatorCelebrityData.setValue(combined);
    }

    @Override
    protected void onCleared() {
        Log.d(MainViewModel.class.getSimpleName(), "MainViewModel cleared");
        super.onCleared();
    }
}